lista = [x for x in range(11, 21)]
print("Lista:", lista)