#include <stdio.h>

int main() {
    // While
    int contador = 0;
    while(contador < 5) {
        printf("Iteração número %d\n", contador);
        contador++;
    }

    return 0;
}