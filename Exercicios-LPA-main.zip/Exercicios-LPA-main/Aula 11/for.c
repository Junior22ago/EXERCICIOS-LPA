#include <stdio.h>

int main() {
    // For
    for(int i = 0; i < 5; i++) {
        printf("Iteração número %d\n", i);
    }

    return 0;
}