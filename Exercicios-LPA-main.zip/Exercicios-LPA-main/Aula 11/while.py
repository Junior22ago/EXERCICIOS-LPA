# While
contador = 0
while contador < 5:
    print(f"Iteração número {contador}")
    contador += 1
