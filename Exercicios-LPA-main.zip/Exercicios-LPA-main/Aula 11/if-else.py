# if simples
numero = 5
if numero > 10:
    print(f"{numero} é maior que 10")
print(f"Fim da verificação simples")

# if-else
idade = 15
if idade >= 18:
    print(f"A pessoa com {idade} anos é maior de idade")
else:
    print(f"A pessoa com {idade} anos é menor de idade")