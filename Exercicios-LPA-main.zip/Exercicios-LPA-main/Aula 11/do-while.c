#include <stdio.h>

int main() {
    // Do-While
    int contador = 0;
    do {
        printf("Executando pelo menos uma vez...\n");
        contador++;
    } while(contador < 5);

    return 0;
}