def imprimir_string(texto):
    print(texto)
    print()

imprimir_string("Hello, World!")
imprimir_string("teste")