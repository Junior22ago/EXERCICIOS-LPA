#include <stdio.h>

int main() {
    printf("Ola\n");
    return 0;
}